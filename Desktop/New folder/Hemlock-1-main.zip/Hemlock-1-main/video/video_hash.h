#ifndef VIDEO_HASH_H
#define VIDEO_HASH_H

int sign_video(const char *video_path);

#endif