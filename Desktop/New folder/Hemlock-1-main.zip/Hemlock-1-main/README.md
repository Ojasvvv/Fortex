# 🌿 HEMLOCK

**Hemlock** is a C-based **Adversarial Defense & Provenance System** running on Asahi Linux. It combines cryptographic signatures (Truth) with gradient-based data poisoning (Defense) to protect images from AI exploitation.



---